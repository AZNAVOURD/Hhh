#!/usr/bin/env python 3
#JapanTools V3.0 Source
#Date 1/1/2020 0h00'000
########################
### AUTO GET PROXIES ###
### CHECK LIVE PROCY ###
### Proxy Http/Https ###
### Sock4/Sock5 Live ###
########################
#############################################################################
##===============================README.TXT================================##
##============INSTRUCTIONS FOR USING THE MOST EFFECTIVE TOOL===============##
## * IN TYPE PROXY:                                                        ##
## - In Other Host , We use Proxy Http whit [https://victim.com] will die ###
## - Another Host , We use Proxy Https whit [http://victim.com] will die  ###
## - Or May be we can use Proxy Http , Https, Socks4, Socks5 whit Victim  ###
## - LIST A PROXY MUST BE ALLWAY FULL,(MUST BE MORE THAN 100 PROXY IN LIST)##
## - YOU MUST BE ALLWAY CHECK AND GET LIVE PROXY FOR TOOL WORD EFFECTIVE ####
## - IF LIST PROXY LESS THAN 100 PROXY ,PRINT ERROR LIST INDEX OUT OF RANGE #
## - SHOULD REMOVE DUPLICATE PROXY  AND KEEP PROXY WITH TIME OUT = < 1      #
## - PROXY LISTS FROM MANY FREE SOURCE CANNOT BE WITH YOUR VIP PROXY.      ##
## - The order of the preferred Proxy Type used for best performance is :  ##
##      --->  Proxy Type SOCK4 - HTTP- SOCK5- HTTPS (SSL Proxy) <---       ##
## - IF CHOOSE TYPE PROXY HTTP-HTTPS ,SHOULD BE FAKE: MAC ADDRESS AND IP   ##
## COMBINATION BETWEEN TYPE PROXY AND METHODS TOOLS FOR EFFICIENT OPERATION #
## - The order of the preferred METHODS TOOLS for best performance is :    ##
##      ---> Method Type [1] - [3] - [2] - [4] - [5] - [6] <---            ##
## - IN METHODS TOOLS:                                                     ##
##   + IF YOU CHOOSE [1]HttpFlood(Default):                                ##
##   ---> URL TARGET: [http://domain.com] OR [http://192.168.1.127:80]     ##
##   ---> MUST BE PORT 80 OR NO PORT IN TARGET [http://192.168.1.127]      ##
##   ---> TYPE PROXY(The order of the preferred): SOCK4 -SOCK5 -HTTP -HTTPS #
##   + IF YOU CHOOSE [2]CloudFlare(Default):                               ##
##   ---> URL TARGET: [http://domain.com] OR [http://192.168.1.127:80]     ##
##   ---> MUST BE PORT 80 OR NO PORT IN TARGET [http://192.168.1.127]      ##
##   ---> TYPE PROXY(The order of the preferred): SOCK4 -SOCK5 -HTTP -HTTPS #
##   ---> METHODS's ONLY AVAILABLE WITH THE BEST SIMPLE CF-URL TYPE(NOT UAM)#
##   + IF YOU CHOOSE [3]HttpFlood(Sockets):                                ##
##   ---> URL TARGET: [http://domain.com] OR [http://192.168.1.127:80]     ##
##   ---> MUST BE PORT 80 OR NO PORT IN TARGET [http://192.168.1.127]      ##
##   ---> TYPE PROXY(The order of the preferred): SOCK4 -SOCK5 -HTTP -HTTPS #
##   ---> CREATE MORE REQUEST THAN OTHER TYPE IF USING TYPE SOCK4           #
##   + IF YOU CHOOSE [4]CloudFlare(Cookies):                               ##
##   ---> URL TARGET: [http://domain.com] OR [http://192.168.1.127:80]     ##
##   ---> MUST BE PORT 80 OR NO PORT IN TARGET [http://192.168.1.127]      ##
##   ---> TYPE PROXY(The order of the preferred): SOCK4 -SOCK5 -HTTP -HTTPS #
##   ---> ONLY USE FOR COOKIES TARGET AND HAVE THE COOKIES TARGET           #
##   + IF YOU CHOOSE [5]Find IP-CF(---SSH) OR [6]Check IP-CF(---DNS):      ##
##   ---> URL TARGET: [http://domain.com] OR [http://192.168.1.127:80]     ##
##   ---> MUST BE PORT 80 OR NO PORT IN TARGET [http://192.168.1.127]      ##
##   ---> TYPE PROXY(The order of the preferred): SOCK4 -SOCK5 -HTTP -HTTPS #
##   --->             YOUR OPTIONAL FOR CHOOSE[5] AND [6]                  ##
##-------FOR TOOLS TO WORK BEST NEEDS COMPUTERS AND HEALTH NETWORKS,--------#
##---MANY PROXY LIVES,KNOWLEDGE TO USE TOOLS AND UNDERSTAND ABOUT TARGET----#
##----SHOULD BE USE STRONG BEST VPS. I ALWAYS UPDATE SOURCE CODE TOOLS.-----#
##==============THACKS FOR WATCHING AND USEING THE TOOLS !!!=================
## COPYRIGHT ON P3TERJ4MES,SOURCE CODE OF P3TERJ4MES,PROHIBITED FOR COPY,   #
## PURCHASE, EDIT CODE UNDER ANY KIND WHEN NOT LEGAL OWN OWNERS ALLOWED !!! #
##         Copyright © 2015-2020 JAPANTOOLS. Design by P3TERJ4MES          ##
##===============================README.END================================##
#############################################################################